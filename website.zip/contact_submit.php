<center>
	<h1 style="font-family: 'ruthie','qwigley','dynalight','euphoria-script','arizonia', 'alex-brush', 'allura', 'italianno'">Thanks</h1>
	<br>
	<br>
	<h3 style="font-family: Baskerville, 'Palatino Linotype', Palatino, 'Century Schoolbook L', 'Times New Roman', 'serif'">Your response has been noted. We will get back to you soon.</h3>
</center>