<div class="footer">
		<div class="container">
			<div class="footer-head">
				<div class="col-md-8 footer-top animated wow fadeInRight" data-wow-duration="1000ms" data-wow-delay="500ms">
					<ul class=" in">
						<li><a href="index_new.php">Home</a></li>
						<li><a  href="menu.php">Menu</a></li>
<!--
						<li><a  href="#">Blog</a></li>
						<li><a  href="#">Events</a></li>
-->
						<li><a  href="contact.php">Contact</a></li>
					</ul>					
<!--					<span style="padding-left: 20px"><h1>Cookery</h1></span>-->
				</div>
				<div class="col-md-4 footer-bottom  animated wow fadeInLeft" data-wow-duration="1000ms" data-wow-delay="500ms">
					<h2>Follow Us</h2>
					<label><i class="glyphicon glyphicon-menu-up"></i></label>
					<p>Connect with us in Social Media, for various new menus, discount, etc.</p>
					<ul class="social-ic">
						<li><a href="https://in.pinterest.com/" target="_blank"><i></i></a></li>
						<li><a href="https://plus.google.com/discover" target="_blank"><i class="ic"></i></a></li>
						<li><a href="https://www.instagram.com/?hl=en" target="_blank"><i class="ic1"></i></a></li>
						<li><a href="https://www.youtube.com/" target="_blank"><i class="ic2"></i></a></li>
						<li><a href="https://www.facebook.com/" target="_blank"><i class="ic3"></i></a></li>
					</ul>

				</div>
			<div class="clearfix"> </div>
					
			</div>
			<p class="footer-class animated wow bounce" data-wow-duration="1000ms" data-wow-delay="500ms">&copy; 2018 Cookery . All Rights Reserved | Design by  <a href="http://w3schools.com/" target="_blank">CMOS</a> </p>
		</div>
	</div>